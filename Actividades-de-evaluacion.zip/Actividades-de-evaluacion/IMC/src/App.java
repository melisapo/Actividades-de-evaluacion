import java.util.Scanner;
public class App {

    public static void main(String[] args) throws Exception {
        //Calcular IMC
        System.out.println("ingrese su peso y estatura separados por renglones");
        Scanner sc = new Scanner(System.in);
        double w= sc.nextDouble();
        double h =sc.nextDouble();
        h=Math.pow(h, 2);
        Double IMC= w/h;
        System.out.println(IMC);  
    }
}
